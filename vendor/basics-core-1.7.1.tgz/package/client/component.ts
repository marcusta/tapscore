// Basics-JS Component
// template() + the Component base class: wire/wireEl bindings, slots, and the
// $each/$condition/$swap directives.

import { effect, untrack } from './signal';
import type { Readable } from './signal';
import { di } from './di';

// ─── Template Helper ─────────────────────────────────────────────

/**
 * Bind names parsed out of an HTML string literal at the type level. Each
 * `bind="name"` occurrence contributes its name to the union. Interpolated
 * templates (`${...}`) become pattern types; when the parse yields nothing
 * usable, `TemplateBinds` falls back to `string` (unconstrained) rather than
 * rejecting every key.
 */
type BindNames<S extends string> =
    S extends `${string}bind="${infer Name}"${infer Rest}`
        ? Name | BindNames<Rest>
        : never;

export type TemplateBinds<S extends string> =
    string extends S ? string
    : [BindNames<S>] extends [never] ? string
    : BindNames<S>;

/**
 * An HTMLTemplateElement carrying its bind names as a phantom type parameter.
 * `__binds` is never set at runtime; it only exists so `wire()` can check the
 * binding map against the template. A plain HTMLTemplateElement is assignable
 * (binds default to `string`, i.e. unconstrained).
 */
export interface Template<B extends string = string> extends HTMLTemplateElement {
    readonly __binds?: B;
}

export function template<const S extends string>(html: S): Template<TemplateBinds<S>> {
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    return tpl as Template<TemplateBinds<S>>;
}

// ─── Helpers ────────────────────────────────────────────────────

function matchPrefix<V>(route: string, map: Record<string, V>): V | undefined {
    let best: string | undefined;
    for (const key of Object.keys(map)) {
        if (route.startsWith(key + '/') && (!best || key.length > best.length)) best = key;
    }
    return best ? map[best] : undefined;
}

// ─── Wire Bindings ───────────────────────────────────────────────

/**
 * A reusable piece of element-scoped behavior — event listeners, focus or
 * dismiss handling — attached through a binding's `mix` key. Behaviors are
 * behavior only: styling stays in CSS recipes. `ctx.track` ties cleanup to the
 * owning scope (the component, or the $each row when wire() got a trackFn);
 * `ctx.signal` aborts when that scope is disposed.
 */
export type Behavior = (el: HTMLElement, ctx: BehaviorContext) => void;

export interface BehaviorContext {
    track(dispose: () => void): void;
    readonly signal: AbortSignal;
}

/** A single wire() binding: a text/value function, or a per-key object. */
export type WireBinding =
    | (() => unknown)
    | ({ mix?: Behavior[] } & Record<string, unknown>);

/**
 * The wire() map, keyed by the template's bind names. Keys are optional —
 * a bind may exist only as a ref() target or a slot/directive host. `NoInfer`
 * keeps the map's own keys out of B's inference, so a typo errors instead of
 * silently widening the union.
 */
export type WireMap<B extends string> = { [K in NoInfer<B>]?: WireBinding };

// ─── Component Base Class ────────────────────────────────────────

const injectedStyles = new Set<Function>();

export type PropsOf<T> = T extends Component<infer P> ? P : {};

export type SlotRenderFn = (host: HTMLElement, ctx: SlotContext) => void;

export type SlotContent =
    | string
    | (new () => Component<any>)
    | SlotRenderFn;

export interface SlotContext {
    spawn<T extends Component<any>>(
        Ctor: new (...args: any[]) => T,
        host: HTMLElement,
        ...args: {} extends PropsOf<T> ? [props?: PropsOf<T>] : [props: PropsOf<T>]
    ): T;
    track(dispose: () => void): void;
}

export abstract class Component<P extends object = {}> {
    private readonly disposers: (() => void)[] = [];
    private readonly children: Component<any>[] = [];
    private abortCtrl: AbortController | null = null;

    constructor(protected readonly props: P = {} as P) {
        const ctor = this.constructor as any;
        if (ctor.styles && !injectedStyles.has(ctor)) {
            injectedStyles.add(ctor);
            const el = document.createElement('style');
            el.textContent = ctor.styles;
            document.head.appendChild(el);
        }
    }

    abstract render(): HTMLElement | DocumentFragment;

    onMount(): void {}
    onDestroy(): void {}

    protected inject<T>(Ctor: new () => T): T { return di.get(Ctor); }

    /**
     * Aborts when the component is destroyed. Pass it to fetch, addEventListener
     * (`{ signal }`), or any other AbortSignal consumer, and the work dies with
     * the component — no matching disposer needed.
     */
    protected get signal(): AbortSignal {
        if (!this.abortCtrl) this.abortCtrl = new AbortController();
        return this.abortCtrl.signal;
    }
    protected track(dispose: () => void): void { this.disposers.push(dispose); }
    protected ref(root: DocumentFragment | HTMLElement, name: string): HTMLElement {
        return root.querySelector(`[bind="${name}"]`) as HTMLElement;
    }

    /**
     * Attach behaviors to an element imperatively — the escape hatch for
     * components that build DOM without wire(). Cleanup is tied to this
     * component's lifetime. Inside wire() maps, prefer the `mix` binding key.
     */
    protected mix(el: HTMLElement, ...behaviors: Behavior[]): void {
        const ctx: BehaviorContext = {
            track: (d: () => void) => this.track(d),
            signal: this.signal,
        };
        for (const b of behaviors) b(el, ctx);
    }

    protected spawn<T extends Component<any>>(
        Ctor: new (...args: any[]) => T,
        host: HTMLElement,
        ...args: {} extends PropsOf<T> ? [props?: PropsOf<T>] : [props: PropsOf<T>]
    ): T {
        // Build + render the child OUTSIDE any tracking context. If spawn() is
        // called from a render that is itself running inside an effect (e.g. a
        // $swap/$each renderer), an untracked boundary stops the child's own
        // signal reads (field initializers, render) from subscribing that outer
        // effect — which would otherwise remount the child on unrelated changes.
        const child = untrack(() => {
            const c = new Ctor(args[0]);
            c.mount(host);
            return c;
        });
        this.children.push(child);
        return child;
    }

    mount(target: HTMLElement): void {
        target.appendChild(this.render());
        this.onMount();
    }

    destroy(): void {
        // Teardown never wants to subscribe an ambient effect. destroy() is
        // routinely called from INSIDE one ($swap's route effect, $each's
        // list effect, app-level effects), and a tracked signal read during
        // teardown (a service's destroy() calling signal.get(), say) would
        // subscribe that outer effect — so the next write to that signal
        // re-runs it and remounts the view that was just torn down.
        untrack(() => {
            // Abort first: in-flight fetches and { signal }-registered listeners
            // stop before teardown runs, not after.
            this.abortCtrl?.abort();
            this.abortCtrl = null;
            this.onDestroy();
            for (const child of this.children) child.destroy();
            this.children.length = 0;
            for (const d of this.disposers) d();
            this.disposers.length = 0;
        });
    }

    protected wire<B extends string>(
        tpl: Template<B>,
        map: WireMap<B>,
        trackFn?: (d: () => void) => void
    ): DocumentFragment {
        const doTrack = trackFn ?? ((d: () => void) => this.track(d));
        const frag = tpl.content.cloneNode(true) as DocumentFragment;

        // One behavior context per wire() call, scoped to doTrack: the
        // component normally, the row when $each passes its trackFn. The
        // controller is lazy — most wire() calls mix nothing.
        let scopeCtrl: AbortController | null = null;
        const ctx: BehaviorContext = {
            track: doTrack,
            get signal() {
                if (!scopeCtrl) {
                    scopeCtrl = new AbortController();
                    doTrack(() => scopeCtrl!.abort());
                }
                return scopeCtrl.signal;
            },
        };

        for (const el of frag.querySelectorAll<HTMLElement>('[bind]')) {
            // Runtime lookup is stringly; B only constrains the map's authoring.
            const binding = (map as Record<string, WireBinding | undefined>)[el.getAttribute('bind')!];
            if (!binding) continue;

            if (typeof binding === 'function') {
                doTrack(effect(() => {
                    const val = binding();
                    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)
                        el.value = String(val);
                    else
                        el.textContent = String(val);
                }));
            } else {
                for (const [key, val] of Object.entries(binding)) {
                    if (key === 'mix') {
                        for (const b of val as Behavior[]) b(el, ctx);
                        continue;
                    }
                    const isAttr = key.includes('-');
                    if (key.startsWith('on') && typeof val === 'function') {
                        // Each invocation gets a fresh AbortSignal (2nd arg) that
                        // aborts when the handler fires again or the scope is
                        // disposed — re-entry cancellation for async handlers.
                        let ctrl: AbortController | null = null;
                        doTrack(() => ctrl?.abort());
                        el.addEventListener(key.slice(2), (e: Event) => {
                            ctrl?.abort();
                            ctrl = new AbortController();
                            (val as (e: Event, signal: AbortSignal) => unknown)(e, ctrl.signal);
                        });
                    }
                    else if (typeof val === 'function')
                        doTrack(effect(() => {
                            const v = (val as () => unknown)();
                            isAttr ? el.setAttribute(key, String(v)) : (el as any)[key] = v;
                        }));
                    else
                        isAttr ? el.setAttribute(key, String(val)) : (el as any)[key] = val;
                }
            }
        }
        return frag;
    }

    protected wireEl<B extends string>(
        tpl: Template<B>,
        map: WireMap<B>,
        trackFn?: (d: () => void) => void
    ): HTMLElement {
        return this.wire(tpl, map, trackFn).firstElementChild as HTMLElement;
    }

    // ─── Slots ────────────────────────────────────────────────────

    protected slot(name: string, root: DocumentFragment | HTMLElement): boolean {
        const content = this.props[name as keyof P] as SlotContent | undefined;
        if (content == null) return false;
        const host = this.ref(root, name);
        if (!host) return false;

        if (typeof content === 'string') {
            host.textContent = content;
        } else if (typeof content === 'function' && content.prototype instanceof Component) {
            this.spawn(content as unknown as new () => Component<any>, host);
        } else if (typeof content === 'function') {
            (content as SlotRenderFn)(host, {
                spawn: <T extends Component<any>>(
                    Ctor: new (...args: any[]) => T,
                    h: HTMLElement,
                    ...args: {} extends PropsOf<T> ? [props?: PropsOf<T>] : [props: PropsOf<T>]
                ) => this.spawn(Ctor, h, ...args),
                track: (d: () => void) => this.track(d),
            });
        }
        return true;
    }

    // ─── Directives ──────────────────────────────────────────────

    protected $each<T>(
        host: HTMLElement,
        items: Readable<T[]> | (() => T[]),
        renderer: (item: T, index: number, track: (d: () => void) => void) => HTMLElement,
        key: (item: T, index: number) => string | number = (_item, index) => index
    ): void {
        const read: () => T[] = typeof items === 'function' ? items : () => items.get();
        const nodes = new Map<string | number, HTMLElement>();
        const scopes = new Map<string | number, (() => void)[]>();

        // Clean up all item scopes when component destroys
        this.track(() => {
            for (const fns of scopes.values()) fns.forEach(d => d());
            scopes.clear();
        });

        this.track(effect(() => {
            const list = read();
            const next = new Map<string | number, HTMLElement>();

            for (const [i, item] of list.entries()) {
                const k = key(item, i);
                if (nodes.has(k)) {
                    next.set(k, nodes.get(k)!);
                } else {
                    const itemDisposers: (() => void)[] = [];
                    // Only the list read drives this effect; build each item's DOM
                    // untracked so a signal read inside a renderer (or a component
                    // it spawns) doesn't re-run the whole list on every change.
                    next.set(k, untrack(() => renderer(item, i, d => itemDisposers.push(d))));
                    scopes.set(k, itemDisposers);
                }
            }

            // Remove deleted nodes from DOM and dispose their effects —
            // untracked, so a disposer's signal read can't subscribe the
            // list effect (same teardown-leak hazard as $swap).
            for (const [k, node] of nodes) {
                if (!next.has(k)) {
                    node.remove();
                    untrack(() => scopes.get(k)?.forEach(d => d()));
                    scopes.delete(k);
                }
            }

            // Minimal DOM moves: walk new order, only move out-of-place nodes
            let cursor = host.firstChild;
            for (const node of next.values()) {
                if (node === cursor) {
                    cursor = cursor.nextSibling;
                } else {
                    host.insertBefore(node, cursor);
                }
            }

            nodes.clear();
            for (const [k, v] of next) nodes.set(k, v);
        }));
    }

    protected $condition(
        host: HTMLElement,
        signal: Readable<boolean>,
        onTrue: () => HTMLElement,
        onFalse?: () => HTMLElement
    ): void {
        let current: HTMLElement | null = null;
        this.track(effect(() => {
            if (current) { current.remove(); current = null; }
            // Read the signal tracked (it drives this effect), then build the
            // branch untracked so the branch's own reads don't subscribe here.
            const show = signal.get();
            current = untrack(() => (show ? onTrue() : onFalse?.() ?? null));
            if (current) host.appendChild(current);
        }));
    }

    protected $swap(
        host: HTMLElement,
        signal: Readable<string>,
        map: Record<string, new () => Component<any>>,
        fallback?: new () => Component<any>
    ): void {
        let child: Component<any> | null = null;
        this.track(effect(() => {
            if (child) {
                // Destroy untracked (belt over Component.destroy's own
                // untrack, which an overridden destroy() could bypass): a
                // tracked read during teardown must not subscribe this
                // effect, or the next write re-enters $swap mid-mount and
                // remounts recursively.
                const prev = child;
                child = null;
                untrack(() => prev.destroy());
            }
            host.textContent = '';
            const route = signal.get();
            const Ctor = map[route] ?? matchPrefix(route, map) ?? fallback;
            if (Ctor) {
                // Only the route read above drives this effect. Build + render
                // the child untracked so ITS reads don't subscribe this effect
                // and cause a remount loop on every signal the child touches.
                child = untrack(() => {
                    const c = new Ctor!();
                    c.mount(host);
                    return c;
                });
            }
        }));
        this.track(() => child?.destroy());
    }
}
