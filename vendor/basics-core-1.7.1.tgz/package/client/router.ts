// Basics-JS Router
// Reactive route/search signals over the History API, with base-path support.

import { BASE_PATH } from './base';
import { Signal, Computed, batch } from './signal';

// ─── Router ─────────────────────────────────────────────────────

export type QueryValue = string | number | boolean | undefined | null;

export interface NavigateOptions {
    replace?: boolean;
    query?: Record<string, QueryValue>;
}

// Base-path support: lets the app be served under a sub-path (e.g.
// '/tapscore/') behind a reverse proxy. The router stores/matches app-relative
// paths; the base is only added to the real URL (pushState) and stripped from
// location reads. See ./base for where the value comes from.
const ROUTER_BASE = BASE_PATH;

/** Internal: used by startApp to detect the /_obs prefix under a base path. */
export function stripBase(pathname: string): string {
    if (!ROUTER_BASE) return pathname;
    if (pathname === ROUTER_BASE) return '/';
    if (pathname.startsWith(ROUTER_BASE + '/')) return pathname.slice(ROUTER_BASE.length);
    return pathname;
}

function withBase(path: string): string {
    return ROUTER_BASE + path;
}

/** Names of the `:seg` params in a route pattern. */
type ParamNames<S extends string> =
    S extends `${string}:${infer P}/${infer Rest}` ? P | ParamNames<`/${Rest}`>
    : S extends `${string}:${infer P}` ? P
    : never;

/**
 * The params object a route pattern yields, extracted at the type level:
 * `RouteParams<'/users/:id'>` is `{ id: string }`. A plain `string` pattern
 * stays an open record.
 */
export type RouteParams<S extends string> =
    string extends S ? Record<string, string> : { [K in ParamNames<S>]: string };

/**
 * Build a concrete path from a pattern and its params — typed, so a missing
 * or misspelled param is a compile error: `href('/users/:id', { id: '7' })`.
 * Patterns without params take no second argument. Values are URI-encoded.
 */
export function href<S extends string>(
    pattern: S,
    ...args: keyof RouteParams<S> extends never ? [] : [params: RouteParams<S>]
): string {
    const params = (args[0] ?? {}) as Record<string, string>;
    return pattern
        .split('/')
        .map(seg => seg.startsWith(':') ? encodeURIComponent(params[seg.slice(1)] ?? '') : seg)
        .join('/');
}

export class Router {
    readonly route = new Signal(stripBase(location.pathname ?? '/'));
    readonly search = new Signal(location.search ?? '');

    constructor() {
        window.addEventListener('popstate', () => batch(() => {
            this.route.set(stripBase(location.pathname));
            this.search.set(location.search);
        }));
    }

    navigate(path: string, opts?: NavigateOptions | boolean): void {
        // Back-compat: navigate(path, true) still means replace.
        const options: NavigateOptions = typeof opts === 'boolean' ? { replace: opts } : (opts ?? {});
        const hashIdx = path.indexOf('#');
        const hash = hashIdx >= 0 ? path.slice(hashIdx) : '';
        const beforeHash = hashIdx >= 0 ? path.slice(0, hashIdx) : path;
        const qIdx = beforeHash.indexOf('?');
        const rawPath = qIdx >= 0 ? beforeHash.slice(0, qIdx) : beforeHash;
        const inlineQuery = qIdx >= 0 ? beforeHash.slice(qIdx + 1) : '';
        const search = options.query !== undefined
            ? serializeQuery(options.query)
            : (inlineQuery ? '?' + inlineQuery : '');
        const url = withBase(rawPath) + search + hash;
        (options.replace ? history.replaceState : history.pushState).call(history, null, '', url);
        batch(() => {
            this.route.set(rawPath);
            this.search.set(search);
        });
    }

    back(): void {
        history.back();
    }

    link(path: string, activeClass = 'active') {
        const pathname = path.split('#')[0]!.split('?')[0]!;
        return {
            onclick: (e: Event) => { e.preventDefault(); this.navigate(path); },
            className: () => {
                const r = this.route.get();
                return r === pathname || r.startsWith(pathname + '/') ? activeClass : '';
            },
        };
    }

    /**
     * Extract named params from a pattern, typed from the pattern itself:
     * `params('/users/:id')` is `Computed<{ id: string }>`.
     */
    params<S extends string>(pattern: S): Computed<RouteParams<S>> {
        const segments = pattern.split('/');
        return new Computed(() => {
            const parts = this.route.get().split('/');
            const result: Record<string, string> = {};
            for (const [i, seg] of segments.entries()) {
                if (seg.startsWith(':')) result[seg.slice(1)] = parts[i] ?? '';
            }
            return result as RouteParams<S>;
        });
    }

    /** Reactive read of a single query parameter. Returns undefined if absent. */
    query(name: string): Computed<string | undefined> {
        return new Computed(() => {
            const params = new URLSearchParams(this.search.get());
            return params.get(name) ?? undefined;
        });
    }

    /** Reactive read of all query parameters as a plain object. */
    queries(): Computed<Record<string, string>> {
        return new Computed(() => {
            const out: Record<string, string> = {};
            for (const [k, v] of new URLSearchParams(this.search.get())) out[k] = v;
            return out;
        });
    }
}

function serializeQuery(q: Record<string, QueryValue>): string {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(q)) {
        if (v === undefined || v === null || v === '') continue;
        params.set(k, String(v));
    }
    const s = params.toString();
    return s ? '?' + s : '';
}
