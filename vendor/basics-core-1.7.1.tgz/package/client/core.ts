// Basics-JS Core
// Public entry point: re-exports the client framework and owns app bootstrap.
// Implementation lives in signal.ts, di.ts, router.ts, theme.ts, component.ts.

export * from './signal';
export * from './di';
export * from './router';
export * from './theme';
export * from './component';

import { effect, untrack } from './signal';
import { di } from './di';
import { Router, stripBase } from './router';
import { Component } from './component';

// ─── App Bootstrap ──────────────────────────────────────────────

interface HotContext {
    data: Record<string, unknown>;
    dispose(cb: () => void): void;
    accept(): void;
}

/**
 * Teardown callbacks to run when the app is disposed — in practice, when Vite
 * replaces the module `startApp` was called from.
 *
 * This exists because Vite keeps exactly ONE dispose callback per module
 * (`disposeMap.set(ownerPath, cb)` in `vite/dist/client/client.mjs`), and
 * `startApp` already claims the app entry's slot for tearing down the component
 * tree. A module that wants disposal of its own — a long-lived service holding
 * a listener, say — therefore cannot reach for `import.meta.hot.dispose()`: it
 * would either overwrite `startApp`'s callback (leaking the whole component
 * tree) or claim its own module's slot, which fires only when THAT module is
 * replaced, which is precisely the case where the stranded instance is created
 * rather than cleaned up.
 *
 * So disposal is registered here and composed by `startApp` instead of
 * competing for a slot that holds one.
 */
const appDisposers = new Set<() => void>();

/**
 * Register `cb` to run when the app is torn down. Returns an unregister
 * function; call it from the owner's own `destroy()` so a disposed instance
 * does not stay reachable through this set.
 *
 * Dev-only in effect: outside HMR nothing disposes an app, so registrations
 * simply accumulate against singletons and are never run. That is why this
 * takes a callback rather than an object with a `destroy()` — there is nothing
 * to keep alive here beyond the closure.
 */
export function onAppDispose(cb: () => void): () => void {
    appDisposers.add(cb);
    return () => appDisposers.delete(cb);
}

/**
 * Drain the registry. Each callback is isolated: one throwing must not strand
 * the ones behind it, because a half-run teardown is the failure mode this is
 * all trying to avoid.
 */
function runAppDisposers(): void {
    for (const cb of Array.from(appDisposers)) {
        appDisposers.delete(cb);
        try {
            cb();
        } catch (err) {
            console.error('[startApp] a dispose callback threw', err);
        }
    }
}

export async function startApp(
    Root: new () => Component<any>,
    root: string | HTMLElement,
    options?: {
        hot?: HotContext | undefined;
        onInit?: (() => void | Promise<void>) | undefined;
        /**
         * Extra teardown to run when the app is disposed, alongside the
         * component tree.
         *
         * Do NOT do this with a second `import.meta.hot.dispose()` in the app
         * entry. Vite stores one dispose callback per module, so a second
         * registration REPLACES the one `startApp` made — trading whatever you
         * were trying to clean up for a leaked component tree. That is a strict
         * loss, and it is why this is a parameter rather than advice.
         */
        onDispose?: (() => void) | undefined;
    }
): Promise<void> {
    const el = typeof root === 'string'
        ? document.querySelector(root) as HTMLElement : root;
    el.textContent = '';

    const router = di.get(Router);
    let app: Component<any> | null = null;
    let inObs = false;
    let ObsShell: (new () => Component<any>) | null = null;
    let initRan = !!options?.hot?.data['hmr'];

    const mount = async (obs: boolean) => {
        if (app) { app.destroy(); app = null; el.textContent = ''; }

        if (obs) {
            if (!ObsShell) {
                const mod = await import('./obs/obs-shell.component');
                ObsShell = mod.ObsShellComponent as unknown as new () => Component<any>;
            }
            app = untrack(() => new ObsShell!());
        } else {
            if (!initRan && options?.onInit) {
                await options.onInit();
                initRan = true;
            }
            app = untrack(() => new Root());
        }

        // mount() is also reachable from the /_obs toggle effect below; build +
        // render the root untracked so it can't subscribe that effect.
        untrack(() => app!.mount(el));
        inObs = obs;
    };

    await mount(stripBase(location.pathname).startsWith('/_obs'));

    effect(() => {
        const wantObs = router.route.get().startsWith('/_obs');
        if (wantObs !== inObs) mount(wantObs);
    });

    if (options?.hot) {
        options.hot.data['hmr'] = true;
        // The app entry's one dispose slot, spent once and composed here.
        //
        // Order is deliberate: the component tree goes first, because it is what
        // holds references INTO the services, and tearing a service down under a
        // live subscriber is the harder failure to reason about. Registered
        // disposers follow, then the caller's own hook last, so an app can rely
        // on everything the framework owns already being closed.
        options.hot.dispose(() => {
            try {
                app?.destroy();
            } catch (err) {
                console.error('[startApp] the root component threw while disposing', err);
            }
            app = null;
            runAppDisposers();
            if (options.onDispose) {
                try {
                    options.onDispose();
                } catch (err) {
                    console.error('[startApp] onDispose threw', err);
                }
            }
        });
        options.hot.accept();
    }
}
