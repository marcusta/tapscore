// Basics-JS Theming
// Token injection (createTokens), scale helper, and the Theme service.

import { controlLengthTokens, controlPropertyCss, normaliseLength } from './default-theme';
import { Signal, effect } from './signal';

// ─── Theming ────────────────────────────────────────────────────

export function createScale<T extends Record<string, string>>(
    values: T
): (name: keyof T & string) => string {
    // name is keyof T — value always exists; ! needed because TS can't narrow Record indexing
    return (name) => values[name]!;
}

/**
 * Design system §03: honouring `prefers-reduced-motion` is global, not
 * per-component — a transition the user cannot tolerate is no better for being
 * declared in a recipe than in a page. Every component here ships transitions,
 * so the framework ships the opt-out with them; leaving it to each app's
 * index.html means the app that forgets never finds out.
 *
 * Injected once per document, from the first `createTokens` call. An app that
 * also carries its own copy in index.html is harmless duplication: the rules
 * are identical and `!important` on both sides makes cascade order irrelevant.
 */
const REDUCED_MOTION_CSS =
    '@media (prefers-reduced-motion: reduce){*,*::before,*::after{'
    + 'animation-duration:.01ms !important;animation-iteration-count:1 !important;'
    + 'transition-duration:.01ms !important}}';

const GLOBAL_CSS_ATTR = 'data-basics-global';

function injectGlobalCss(): void {
    // createTokens can run more than once — an app may re-theme, and obs/ scopes
    // a second token set of its own. The marker attribute keeps this to one copy.
    if (document.head.querySelector(`style[${GLOBAL_CSS_ATTR}]`)) return;
    const style = document.createElement('style');
    style.setAttribute(GLOBAL_CSS_ATTR, '');
    // The @property registrations must precede everything: they are what makes
    // a hand-written `--field-border-width: 0` compute to a length instead of
    // invalidating the max() that draws the field's control boundary.
    style.textContent = controlPropertyCss() + REDUCED_MOTION_CSS;
    document.head.appendChild(style);
}

export function createTokens<T extends Record<string, string>>(
    light: T,
    dark: T
): (name: keyof T & string) => string {
    injectGlobalCss();
    /*
     * Length-valued control tokens are normalised on the way out. A theme may
     * legitimately write `--field-border-width: 0` or `thin` — both are valid
     * `<line-width>` — but neither is a `<length>`, and the field recipe feeds
     * these two into a `max()` that is silently dropped if either operand is
     * not a length, taking the field's control boundary with it. Rewriting them
     * here means a theme never has to know that, and the value it meant is what
     * ships. See `normaliseLength` in default-theme.ts.
     */
    const lengths = new Set(controlLengthTokens);
    const toBlock = (obj: Record<string, string>, sel: string, scheme: string) => {
        const vars = Object.entries(obj)
            .map(([k, v]) => `--${k}:${lengths.has(k) ? normaliseLength(v) : v}`)
            .join(';');
        return `${sel}{color-scheme:${scheme};${vars}}`;
    };
    const style = document.createElement('style');
    style.textContent = toBlock(light, '[data-theme="light"]', 'light')
        + toBlock(dark, '[data-theme="dark"]', 'dark');
    document.head.appendChild(style);
    return (name) => `var(--${name})`;
}

const THEME_KEY = 'basics-js-theme';

export class Theme {
    readonly dark = new Signal(false);

    constructor() {
        const stored = localStorage.getItem(THEME_KEY);
        const prefersDark = matchMedia('(prefers-color-scheme: dark)').matches;
        this.dark.set(stored ? stored === 'dark' : prefersDark);
        effect(() => {
            const isDark = this.dark.get();
            document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
            localStorage.setItem(THEME_KEY, isDark ? 'dark' : 'light');
        });
    }

    toggle(): void { this.dark.update(v => !v); }
}

