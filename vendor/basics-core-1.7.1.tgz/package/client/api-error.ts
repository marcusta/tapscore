export class ApiError extends Error {
    constructor(
        public readonly status: number,
        message: string,
        public readonly details?: { path: string; message: string }[],
        public readonly traceId?: string,
        /** Server-provided structured payload (`{ error, detail }` responses, e.g. ConflictError). */
        public readonly detail?: unknown,
    ) {
        super(message);
        this.name = 'ApiError';
    }
}
