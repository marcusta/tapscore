// Basics-JS Signals
// Pull-based, glitch-free reactivity: Signal, Computed, effect, batch, untrack.

import { reportError } from './error-report';

// ─── Signal System ───────────────────────────────────────────────
//
// Pull-based and glitch-free. A write marks the graph downstream of the
// signal (computeds DIRTY or CHECK, effects queued) and then flushes the
// effect queue once. Each effect runs at most once per write, and a computed
// recomputes only when an effect (or a direct `.get()`) pulls it, after its
// own sources have settled. An effect therefore never observes a computed
// that is stale relative to the signal that just changed (the "diamond"
// glitch a plain push scheduler has), and never runs twice for one write.
//
// Writes stay synchronous: when `set()` returns, every affected effect has
// run. A write made from inside a running effect joins the current flush.

const CLEAN = 0;
/** A source upstream may have changed; verify before recomputing. */
const CHECK = 1;
/** A direct source changed; must recompute. */
const DIRTY = 2;
type State = typeof CLEAN | typeof CHECK | typeof DIRTY;

/** Anything that can be read and tracked: a Signal or a Computed. */
type Source = {
    readonly subs: Set<Subscriber>;
    /** Bumped every time the value actually changes. `settle` compares this
     *  against the version a subscriber saw, so "did it change?" is answered
     *  per subscriber — a `refresh()` return value would be consumed by
     *  whichever reader refreshed first and lost to everyone after. */
    version: number;
    /** Computed only. Bring the value up to date (bumping `version` if it changed). */
    refresh?(): void;
};

/** Anything that reads sources: a Computed or an effect. */
type Subscriber = {
    state: State;
    /** Sources read during the last run, in read order, each with the
     *  source version the run observed. */
    readonly sources: Map<Source, number>;
    /** Computed only: downstream subscribers to mark CHECK when this node is marked. */
    readonly subs?: Set<Subscriber>;
    /** Effect only: the body, run by the flush. */
    run?(): void;
    /** Set by an effect's disposer. A disposed subscriber never runs again —
     *  including a run already queued when it was disposed. */
    disposed?: boolean;
};

/** Upper bound on effect runs in one flush. An effect that writes a signal it
 *  reads would otherwise spin forever; fail loudly instead. */
const MAX_FLUSH_RUNS = 100_000;

class Scheduler {
    private tracking: Subscriber | null = null;
    private batchDepth = 0;
    private flushing = false;
    private readonly queue: Subscriber[] = [];

    subscribe(src: Source): void {
        const t = this.tracking;
        if (t) {
            src.subs.add(t);
            t.sources.set(src, src.version);
        }
    }

    /** A signal changed: mark everything downstream, then flush unless deferred. */
    notify(subs: Set<Subscriber>): void {
        for (const s of subs) this.mark(s, DIRTY);
        if (this.batchDepth === 0 && !this.flushing) this.flush();
    }

    private mark(s: Subscriber, state: State): void {
        if (s.disposed || s.state >= state) return;
        const wasClean = s.state === CLEAN;
        s.state = state;
        // Downstream was already marked when this node left CLEAN; a later
        // CHECK→DIRTY upgrade changes nothing for it.
        if (!wasClean) return;
        if (s.run) this.queue.push(s);
        else if (s.subs) for (const d of s.subs) this.mark(d, CHECK);
    }

    /** Resolve CHECK: refresh computed sources in read order. The first one
     *  whose version moved past what this node saw makes it DIRTY; none makes
     *  it CLEAN. Versions, not refresh-returned flags: a change flag would be
     *  consumed by whichever subscriber (or direct `.get()`) refreshed first. */
    settle(s: Subscriber): void {
        if (s.state !== CHECK) return;
        for (const [src, seen] of s.sources) {
            src.refresh?.();
            if (src.version !== seen) { s.state = DIRTY; return; }
        }
        s.state = CLEAN;
    }

    runTracked(sub: Subscriber, fn: () => void): void {
        // A disposed subscriber must not run — and must not re-subscribe. A
        // subscriber disposed DURING a flush (a component destroyed by an
        // earlier effect in the same flush) is still in the queue; without
        // this guard it runs with stale state and `runTracked` re-adds it to
        // every signal it reads, i.e. the torn-down view comes back to life
        // and keeps writing.
        if (sub.disposed) return;
        teardown(sub);
        const prev = this.tracking;
        this.tracking = sub;
        try { fn(); } finally { this.tracking = prev; }
    }

    untrack<T>(fn: () => T): T {
        const prev = this.tracking;
        this.tracking = null;
        try { return fn(); } finally { this.tracking = prev; }
    }

    batch(fn: () => void): void {
        this.batchDepth++;
        try { fn(); } finally {
            this.batchDepth--;
            if (this.batchDepth === 0 && !this.flushing) this.flush();
        }
    }

    /** Run every queued effect once. Each run is isolated: one effect
     *  throwing must not leave the rest of the graph un-updated. */
    private flush(): void {
        this.flushing = true;
        let runs = 0;
        try {
            while (this.queue.length) {
                if (++runs > MAX_FLUSH_RUNS) {
                    this.queue.length = 0;
                    throw new Error('[effect] flush did not converge: an effect keeps writing a signal it reads');
                }
                const s = this.queue.shift()!;
                if (s.disposed) { s.state = CLEAN; continue; }
                try {
                    this.settle(s);
                    if (s.state !== DIRTY) continue;
                    s.state = CLEAN;
                    s.run!();
                } catch (err) {
                    s.state = CLEAN;
                    reportEffectError(err);
                }
            }
        } finally {
            this.flushing = false;
        }
    }
}

const scheduler = new Scheduler();

function teardown(sub: Subscriber): void {
    for (const src of sub.sources.keys()) src.subs.delete(sub);
    sub.sources.clear();
}

function reportEffectError(err: unknown): void {
    console.error('[effect] an effect threw', err);
    const message = err instanceof Error ? err.message : String(err);
    reportError('effect', message);
}

export interface Readable<T> { get(): T; }

export class Signal<T> {
    private val: T;
    private readonly src: Source = { subs: new Set(), version: 0 };

    constructor(initial: T) { this.val = initial; }

    get(): T {
        scheduler.subscribe(this.src);
        return this.val;
    }

    /** Read the current value WITHOUT subscribing the active effect. */
    peek(): T { return this.val; }

    set(next: T): void {
        if (Object.is(this.val, next)) return;
        this.val = next;
        this.src.version++;
        scheduler.notify(this.src.subs);
    }

    update(fn: (current: T) => T): void {
        this.set(fn(this.val));
    }
}

export class Computed<T> {
    private val: T;
    private readonly node: Subscriber & Required<Source>;

    constructor(fn: () => T) {
        this.val = undefined as T;
        const self = this;
        const node: Subscriber & Required<Source> = {
            state: DIRTY,
            sources: new Map(),
            subs: new Set(),
            version: 0,
            refresh(): void {
                scheduler.settle(node);
                if (node.state !== DIRTY) return;
                scheduler.runTracked(node, () => {
                    const next = fn();
                    if (!Object.is(self.val, next)) {
                        self.val = next;
                        node.version++;
                    }
                });
                // Only after a successful run: a throwing `fn` leaves the node
                // DIRTY so the next read retries instead of serving a stale value.
                node.state = CLEAN;
            },
        };
        this.node = node;
        node.refresh();
    }

    get(): T {
        this.node.refresh();
        scheduler.subscribe(this.node);
        return this.val;
    }

    /** Read the current value WITHOUT subscribing the active effect. */
    peek(): T {
        this.node.refresh();
        return this.val;
    }
}

export function effect(fn: () => void): () => void {
    const sub: Subscriber = {
        state: CLEAN,
        sources: new Map(),
        run() { scheduler.runTracked(sub, fn); },
    };
    scheduler.runTracked(sub, fn);
    return () => {
        sub.disposed = true;
        teardown(sub);
    };
}

export function batch(fn: () => void): void {
    scheduler.batch(fn);
}

/**
 * Run `fn` with reactive tracking suspended: signal reads inside it do NOT
 * subscribe the currently-running effect. Use it to isolate side work — most
 * importantly building a child component — from the effect that triggered it,
 * so the child's construction/render can't leak its reads into the parent's
 * dependency set. Nested `effect()`/`Computed` inside still track normally.
 */
export function untrack<T>(fn: () => T): T {
    return scheduler.untrack(fn);
}
