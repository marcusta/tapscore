// Basics-JS Dependency Injection

// ─── Dependency Injection ────────────────────────────────────────

export class Container {
    private readonly instances = new Map<Function, unknown>();

    get<T>(Ctor: new () => T): T {
        let inst = this.instances.get(Ctor) as T | undefined;
        if (!inst) {
            inst = new Ctor();
            this.instances.set(Ctor, inst);
        }
        return inst;
    }

    set<T>(Ctor: new (...args: any[]) => T, instance: T): void {
        this.instances.set(Ctor, instance);
    }

    reset(): void {
        this.instances.clear();
    }
}

export const di = new Container();

