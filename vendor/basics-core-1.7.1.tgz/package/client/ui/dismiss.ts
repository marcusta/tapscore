// Dismiss behaviors: close on an outside pointer press, close on Escape.
//
// Both listen on `document` only while `open` is true. This is the one
// canonical outside-dismiss implementation — components must not hand-roll
// their own document listeners for this.

import { effect } from '../signal';
import type { Readable } from '../signal';
import type { Behavior } from '../component';

export interface DismissOptions {
    /** Extra elements that count as inside (e.g. a portaled dropdown). */
    within?: () => Element[];
}

/**
 * Close when a pointer press lands outside the element. Capture phase, so the
 * press is seen before the pressed element can swallow the event — and opening
 * one widget closes any other, which a per-instance backdrop cannot guarantee
 * across stacking contexts.
 */
export function dismissOnOutside(
    open: Readable<boolean>,
    dismiss: () => void,
    opts?: DismissOptions
): Behavior {
    return (el, ctx) => {
        const onPointer = (e: Event): void => {
            const target = e.target as Node;
            if (el.contains(target)) return;
            if (opts?.within?.().some(r => r.contains(target))) return;
            dismiss();
        };
        ctx.track(effect(() => {
            if (open.get()) document.addEventListener('pointerdown', onPointer, true);
            else document.removeEventListener('pointerdown', onPointer, true);
        }));
        ctx.track(() => document.removeEventListener('pointerdown', onPointer, true));
    };
}

/** Close on Escape. Listens on `document`, so focus need not be inside. */
export function dismissOnEscape(open: Readable<boolean>, dismiss: () => void): Behavior {
    return (_el, ctx) => {
        const onKeydown = (e: KeyboardEvent): void => {
            if (e.key !== 'Escape') return;
            e.preventDefault();
            dismiss();
        };
        ctx.track(effect(() => {
            if (open.get()) document.addEventListener('keydown', onKeydown, true);
            else document.removeEventListener('keydown', onKeydown, true);
        }));
        ctx.track(() => document.removeEventListener('keydown', onKeydown, true));
    };
}
