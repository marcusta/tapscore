// Roving-focus behavior: arrow-key navigation over a set of focus stops with
// a roving tabindex (the focused item is the composite's one tab stop).
//
// The behavior owns navigation only. The component owns the INITIAL tab stop —
// set `tabindex="0"` on the active item and `-1` on the rest (tabs does this in
// its active-state effect; a menu does it when it opens). From there, focusin
// and arrow keys keep the roving state current.

import type { Behavior } from '../component';

export interface RovingOptions {
    /** The focus stops, in visual order. Re-read on every keystroke. */
    items: () => HTMLElement[];
    /** Which arrow pair navigates. Default 'horizontal'. */
    orientation?: 'horizontal' | 'vertical' | 'both';
    /** Wrap from last to first and back. Default true. */
    wrap?: boolean;
}

export function rovingFocus(opts: RovingOptions): Behavior {
    const orientation = opts.orientation ?? 'horizontal';
    const wrap = opts.wrap ?? true;
    const nextKeys = orientation === 'horizontal' ? ['ArrowRight']
        : orientation === 'vertical' ? ['ArrowDown']
        : ['ArrowRight', 'ArrowDown'];
    const prevKeys = orientation === 'horizontal' ? ['ArrowLeft']
        : orientation === 'vertical' ? ['ArrowUp']
        : ['ArrowLeft', 'ArrowUp'];

    return (el, ctx) => {
        const setStop = (items: HTMLElement[], target: HTMLElement): void => {
            for (const item of items) item.tabIndex = item === target ? 0 : -1;
        };

        // A click or programmatic focus on any stop makes it THE stop.
        el.addEventListener('focusin', (e) => {
            const items = opts.items();
            const target = e.target as HTMLElement;
            if (items.includes(target)) setStop(items, target);
        }, { signal: ctx.signal });

        el.addEventListener('keydown', (e: KeyboardEvent) => {
            const all = opts.items();
            const items = all.filter(i => !i.hasAttribute('disabled'));
            if (items.length === 0) return;
            const current = items.indexOf(document.activeElement as HTMLElement);
            let next: number;
            if (nextKeys.includes(e.key)) {
                next = current < 0 ? 0
                    : current + 1 < items.length ? current + 1
                    : wrap ? 0 : current;
            } else if (prevKeys.includes(e.key)) {
                next = current < 0 ? items.length - 1
                    : current - 1 >= 0 ? current - 1
                    : wrap ? items.length - 1 : current;
            } else if (e.key === 'Home') {
                next = 0;
            } else if (e.key === 'End') {
                next = items.length - 1;
            } else {
                return;
            }
            e.preventDefault();
            const target = items[next]!;
            setStop(all, target);
            target.focus();
        }, { signal: ctx.signal });
    };
}
