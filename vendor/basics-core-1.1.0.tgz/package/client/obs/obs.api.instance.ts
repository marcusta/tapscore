import { API_BASE } from '../base';
import { createObsClient } from './obs.client';

// Must go through API_BASE (see base.ts) — a literal '/api/_obs' resolves
// against the origin root and misses the service on path-routed deploys.
export const obsApi = createObsClient(`${API_BASE}/_obs`);
