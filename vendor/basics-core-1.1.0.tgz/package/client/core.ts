// Basics-JS Core
// Signal reactivity, DI, Component base class, directives

import { BASE_PATH } from './base';
import { controlLengthTokens, controlPropertyCss, normaliseLength } from './default-theme';

// ─── Signal System ───────────────────────────────────────────────

type Subscriber = {
    run(): void;
    deps: Set<Set<Subscriber>>;
    /** Set by an effect's disposer. A disposed subscriber never runs again —
     *  including a run already queued in `pending` when it was disposed. */
    disposed?: boolean;
};

class Scheduler {
    private tracking: Subscriber | null = null;
    private batching = false;
    private readonly pending = new Set<Subscriber>();

    subscribe(subs: Set<Subscriber>): void {
        if (this.tracking) {
            subs.add(this.tracking);
            this.tracking.deps.add(subs);
        }
    }

    notify(subs: Set<Subscriber>): void {
        for (const s of [...subs]) {
            if (s.disposed) continue;
            this.batching ? this.pending.add(s) : s.run();
        }
    }

    runTracked(sub: Subscriber, fn: () => void): void {
        // A disposed subscriber must not run — and must not re-subscribe. The
        // flush below snapshots `pending`, so a subscriber disposed DURING the
        // flush (a component destroyed by an earlier effect in the same batch)
        // is still in that snapshot; without this guard it runs with stale
        // state and `runTracked` re-adds it to every signal it reads, i.e. the
        // torn-down view comes back to life and keeps writing.
        if (sub.disposed) return;
        teardown(sub);
        const prev = this.tracking;
        this.tracking = sub;
        try { fn(); } finally { this.tracking = prev; }
    }

    untrack<T>(fn: () => T): T {
        const prev = this.tracking;
        this.tracking = null;
        try { return fn(); } finally { this.tracking = prev; }
    }

    batch(fn: () => void): void {
        this.batching = true;
        try { fn(); } finally {
            this.batching = false;
            const queued = [...this.pending];
            this.pending.clear();
            for (const s of queued) if (!s.disposed) s.run();
        }
    }
}

const scheduler = new Scheduler();

function teardown(sub: Subscriber): void {
    for (const set of sub.deps) set.delete(sub);
    sub.deps.clear();
}

export interface Readable<T> { get(): T; }

export class Signal<T> {
    private val: T;
    private readonly subs = new Set<Subscriber>();

    constructor(initial: T) { this.val = initial; }

    get(): T {
        scheduler.subscribe(this.subs);
        return this.val;
    }

    /** Read the current value WITHOUT subscribing the active effect. */
    peek(): T { return this.val; }

    set(next: T): void {
        if (Object.is(this.val, next)) return;
        this.val = next;
        scheduler.notify(this.subs);
    }

    update(fn: (current: T) => T): void {
        this.set(fn(this.val));
    }
}

export class Computed<T> {
    private val: T;
    private readonly subs = new Set<Subscriber>();

    constructor(fn: () => T) {
        this.val = undefined as T;
        const self = this;
        const sub: Subscriber = {
            run() {
                scheduler.runTracked(sub, () => {
                    const next = fn();
                    if (!Object.is(self.val, next)) {
                        self.val = next;
                        scheduler.notify(self.subs);
                    }
                });
            },
            deps: new Set(),
        };
        sub.run();
    }

    get(): T {
        scheduler.subscribe(this.subs);
        return this.val;
    }

    /** Read the current value WITHOUT subscribing the active effect. */
    peek(): T { return this.val; }
}

export function effect(fn: () => void): () => void {
    const sub: Subscriber = {
        run() { scheduler.runTracked(sub, fn); },
        deps: new Set(),
    };
    sub.run();
    return () => {
        sub.disposed = true;
        teardown(sub);
    };
}

export function batch(fn: () => void): void {
    scheduler.batch(fn);
}

/**
 * Run `fn` with reactive tracking suspended: signal reads inside it do NOT
 * subscribe the currently-running effect. Use it to isolate side work — most
 * importantly building a child component — from the effect that triggered it,
 * so the child's construction/render can't leak its reads into the parent's
 * dependency set. Nested `effect()`/`Computed` inside still track normally.
 */
export function untrack<T>(fn: () => T): T {
    return scheduler.untrack(fn);
}

// ─── Dependency Injection ────────────────────────────────────────

export class Container {
    private readonly instances = new Map<Function, unknown>();

    get<T>(Ctor: new () => T): T {
        let inst = this.instances.get(Ctor) as T | undefined;
        if (!inst) {
            inst = new Ctor();
            this.instances.set(Ctor, inst);
        }
        return inst;
    }

    set<T>(Ctor: new (...args: any[]) => T, instance: T): void {
        this.instances.set(Ctor, instance);
    }

    reset(): void {
        this.instances.clear();
    }
}

export const di = new Container();

// ─── Router ─────────────────────────────────────────────────────

export type QueryValue = string | number | boolean | undefined | null;

export interface NavigateOptions {
    replace?: boolean;
    query?: Record<string, QueryValue>;
}

// Base-path support: lets the app be served under a sub-path (e.g.
// '/tapscore/') behind a reverse proxy. The router stores/matches app-relative
// paths; the base is only added to the real URL (pushState) and stripped from
// location reads. See ./base for where the value comes from.
const ROUTER_BASE = BASE_PATH;

function stripBase(pathname: string): string {
    if (!ROUTER_BASE) return pathname;
    if (pathname === ROUTER_BASE) return '/';
    if (pathname.startsWith(ROUTER_BASE + '/')) return pathname.slice(ROUTER_BASE.length);
    return pathname;
}

function withBase(path: string): string {
    return ROUTER_BASE + path;
}

export class Router {
    readonly route = new Signal(stripBase(location.pathname ?? '/'));
    readonly search = new Signal(location.search ?? '');

    constructor() {
        window.addEventListener('popstate', () => batch(() => {
            this.route.set(stripBase(location.pathname));
            this.search.set(location.search);
        }));
    }

    navigate(path: string, opts?: NavigateOptions | boolean): void {
        // Back-compat: navigate(path, true) still means replace.
        const options: NavigateOptions = typeof opts === 'boolean' ? { replace: opts } : (opts ?? {});
        const hashIdx = path.indexOf('#');
        const hash = hashIdx >= 0 ? path.slice(hashIdx) : '';
        const beforeHash = hashIdx >= 0 ? path.slice(0, hashIdx) : path;
        const qIdx = beforeHash.indexOf('?');
        const rawPath = qIdx >= 0 ? beforeHash.slice(0, qIdx) : beforeHash;
        const inlineQuery = qIdx >= 0 ? beforeHash.slice(qIdx + 1) : '';
        const search = options.query !== undefined
            ? serializeQuery(options.query)
            : (inlineQuery ? '?' + inlineQuery : '');
        const url = withBase(rawPath) + search + hash;
        (options.replace ? history.replaceState : history.pushState).call(history, null, '', url);
        batch(() => {
            this.route.set(rawPath);
            this.search.set(search);
        });
    }

    back(): void {
        history.back();
    }

    link(path: string, activeClass = 'active') {
        const pathname = path.split('#')[0]!.split('?')[0]!;
        return {
            onclick: (e: Event) => { e.preventDefault(); this.navigate(path); },
            className: () => {
                const r = this.route.get();
                return r === pathname || r.startsWith(pathname + '/') ? activeClass : '';
            },
        };
    }

    /** Extract named params from a pattern. e.g. params('/users/:id') */
    params<T extends Record<string, string> = Record<string, string>>(pattern: string): Computed<T> {
        const segments = pattern.split('/');
        return new Computed(() => {
            const parts = this.route.get().split('/');
            const result: Record<string, string> = {};
            for (const [i, seg] of segments.entries()) {
                if (seg.startsWith(':')) result[seg.slice(1)] = parts[i] ?? '';
            }
            return result as T;
        });
    }

    /** Reactive read of a single query parameter. Returns undefined if absent. */
    query(name: string): Computed<string | undefined> {
        return new Computed(() => {
            const params = new URLSearchParams(this.search.get());
            return params.get(name) ?? undefined;
        });
    }

    /** Reactive read of all query parameters as a plain object. */
    queries(): Computed<Record<string, string>> {
        return new Computed(() => {
            const out: Record<string, string> = {};
            for (const [k, v] of new URLSearchParams(this.search.get())) out[k] = v;
            return out;
        });
    }
}

function serializeQuery(q: Record<string, QueryValue>): string {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(q)) {
        if (v === undefined || v === null || v === '') continue;
        params.set(k, String(v));
    }
    const s = params.toString();
    return s ? '?' + s : '';
}

// ─── Theming ────────────────────────────────────────────────────

export function createScale<T extends Record<string, string>>(
    values: T
): (name: keyof T & string) => string {
    // name is keyof T — value always exists; ! needed because TS can't narrow Record indexing
    return (name) => values[name]!;
}

/**
 * Design system §03: honouring `prefers-reduced-motion` is global, not
 * per-component — a transition the user cannot tolerate is no better for being
 * declared in a recipe than in a page. Every component here ships transitions,
 * so the framework ships the opt-out with them; leaving it to each app's
 * index.html means the app that forgets never finds out.
 *
 * Injected once per document, from the first `createTokens` call. An app that
 * also carries its own copy in index.html is harmless duplication: the rules
 * are identical and `!important` on both sides makes cascade order irrelevant.
 */
const REDUCED_MOTION_CSS =
    '@media (prefers-reduced-motion: reduce){*,*::before,*::after{'
    + 'animation-duration:.01ms !important;animation-iteration-count:1 !important;'
    + 'transition-duration:.01ms !important}}';

const GLOBAL_CSS_ATTR = 'data-basics-global';

function injectGlobalCss(): void {
    // createTokens can run more than once — an app may re-theme, and obs/ scopes
    // a second token set of its own. The marker attribute keeps this to one copy.
    if (document.head.querySelector(`style[${GLOBAL_CSS_ATTR}]`)) return;
    const style = document.createElement('style');
    style.setAttribute(GLOBAL_CSS_ATTR, '');
    // The @property registrations must precede everything: they are what makes
    // a hand-written `--field-border-width: 0` compute to a length instead of
    // invalidating the max() that draws the field's control boundary.
    style.textContent = controlPropertyCss() + REDUCED_MOTION_CSS;
    document.head.appendChild(style);
}

export function createTokens<T extends Record<string, string>>(
    light: T,
    dark: T
): (name: keyof T & string) => string {
    injectGlobalCss();
    /*
     * Length-valued control tokens are normalised on the way out. A theme may
     * legitimately write `--field-border-width: 0` or `thin` — both are valid
     * `<line-width>` — but neither is a `<length>`, and the field recipe feeds
     * these two into a `max()` that is silently dropped if either operand is
     * not a length, taking the field's control boundary with it. Rewriting them
     * here means a theme never has to know that, and the value it meant is what
     * ships. See `normaliseLength` in default-theme.ts.
     */
    const lengths = new Set(controlLengthTokens);
    const toBlock = (obj: Record<string, string>, sel: string, scheme: string) => {
        const vars = Object.entries(obj)
            .map(([k, v]) => `--${k}:${lengths.has(k) ? normaliseLength(v) : v}`)
            .join(';');
        return `${sel}{color-scheme:${scheme};${vars}}`;
    };
    const style = document.createElement('style');
    style.textContent = toBlock(light, '[data-theme="light"]', 'light')
        + toBlock(dark, '[data-theme="dark"]', 'dark');
    document.head.appendChild(style);
    return (name) => `var(--${name})`;
}

const THEME_KEY = 'basics-js-theme';

export class Theme {
    readonly dark = new Signal(false);

    constructor() {
        const stored = localStorage.getItem(THEME_KEY);
        const prefersDark = matchMedia('(prefers-color-scheme: dark)').matches;
        this.dark.set(stored ? stored === 'dark' : prefersDark);
        effect(() => {
            const isDark = this.dark.get();
            document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
            localStorage.setItem(THEME_KEY, isDark ? 'dark' : 'light');
        });
    }

    toggle(): void { this.dark.update(v => !v); }
}

// ─── Template Helper ─────────────────────────────────────────────

export function template(html: string): HTMLTemplateElement {
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    return tpl;
}

// ─── Helpers ────────────────────────────────────────────────────

function matchPrefix<V>(route: string, map: Record<string, V>): V | undefined {
    let best: string | undefined;
    for (const key of Object.keys(map)) {
        if (route.startsWith(key + '/') && (!best || key.length > best.length)) best = key;
    }
    return best ? map[best] : undefined;
}

// ─── Component Base Class ────────────────────────────────────────

const injectedStyles = new Set<Function>();

export type PropsOf<T> = T extends Component<infer P> ? P : {};

export type SlotRenderFn = (host: HTMLElement, ctx: SlotContext) => void;

export type SlotContent =
    | string
    | (new () => Component<any>)
    | SlotRenderFn;

export interface SlotContext {
    spawn<T extends Component<any>>(
        Ctor: new (...args: any[]) => T,
        host: HTMLElement,
        ...args: {} extends PropsOf<T> ? [props?: PropsOf<T>] : [props: PropsOf<T>]
    ): T;
    track(dispose: () => void): void;
}

export abstract class Component<P extends object = {}> {
    private readonly disposers: (() => void)[] = [];
    private readonly children: Component<any>[] = [];

    constructor(protected readonly props: P = {} as P) {
        const ctor = this.constructor as any;
        if (ctor.styles && !injectedStyles.has(ctor)) {
            injectedStyles.add(ctor);
            const el = document.createElement('style');
            el.textContent = ctor.styles;
            document.head.appendChild(el);
        }
    }

    abstract render(): HTMLElement | DocumentFragment;

    onMount(): void {}
    onDestroy(): void {}

    protected inject<T>(Ctor: new () => T): T { return di.get(Ctor); }
    protected track(dispose: () => void): void { this.disposers.push(dispose); }
    protected ref(root: DocumentFragment | HTMLElement, name: string): HTMLElement {
        return root.querySelector(`[bind="${name}"]`) as HTMLElement;
    }

    protected spawn<T extends Component<any>>(
        Ctor: new (...args: any[]) => T,
        host: HTMLElement,
        ...args: {} extends PropsOf<T> ? [props?: PropsOf<T>] : [props: PropsOf<T>]
    ): T {
        // Build + render the child OUTSIDE any tracking context. If spawn() is
        // called from a render that is itself running inside an effect (e.g. a
        // $swap/$each renderer), an untracked boundary stops the child's own
        // signal reads (field initializers, render) from subscribing that outer
        // effect — which would otherwise remount the child on unrelated changes.
        const child = untrack(() => {
            const c = new Ctor(args[0]);
            c.mount(host);
            return c;
        });
        this.children.push(child);
        return child;
    }

    mount(target: HTMLElement): void {
        target.appendChild(this.render());
        this.onMount();
    }

    destroy(): void {
        // Teardown never wants to subscribe an ambient effect. destroy() is
        // routinely called from INSIDE one ($swap's route effect, $each's
        // list effect, app-level effects), and a tracked signal read during
        // teardown (a service's destroy() calling signal.get(), say) would
        // subscribe that outer effect — so the next write to that signal
        // re-runs it and remounts the view that was just torn down.
        untrack(() => {
            this.onDestroy();
            for (const child of this.children) child.destroy();
            this.children.length = 0;
            for (const d of this.disposers) d();
            this.disposers.length = 0;
        });
    }

    protected wire(
        tpl: HTMLTemplateElement,
        map: Record<string, (() => unknown) | Record<string, unknown>>,
        trackFn?: (d: () => void) => void
    ): DocumentFragment {
        const doTrack = trackFn ?? ((d: () => void) => this.track(d));
        const frag = tpl.content.cloneNode(true) as DocumentFragment;

        for (const el of frag.querySelectorAll<HTMLElement>('[bind]')) {
            const binding = map[el.getAttribute('bind')!];
            if (!binding) continue;

            if (typeof binding === 'function') {
                doTrack(effect(() => {
                    const val = binding();
                    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)
                        el.value = String(val);
                    else
                        el.textContent = String(val);
                }));
            } else {
                for (const [key, val] of Object.entries(binding)) {
                    const isAttr = key.includes('-');
                    if (key.startsWith('on') && typeof val === 'function')
                        el.addEventListener(key.slice(2), val as EventListener);
                    else if (typeof val === 'function')
                        doTrack(effect(() => {
                            const v = (val as () => unknown)();
                            isAttr ? el.setAttribute(key, String(v)) : (el as any)[key] = v;
                        }));
                    else
                        isAttr ? el.setAttribute(key, String(val)) : (el as any)[key] = val;
                }
            }
        }
        return frag;
    }

    protected wireEl(
        tpl: HTMLTemplateElement,
        map: Record<string, (() => unknown) | Record<string, unknown>>,
        trackFn?: (d: () => void) => void
    ): HTMLElement {
        return this.wire(tpl, map, trackFn).firstElementChild as HTMLElement;
    }

    // ─── Slots ────────────────────────────────────────────────────

    protected slot(name: string, root: DocumentFragment | HTMLElement): boolean {
        const content = this.props[name as keyof P] as SlotContent | undefined;
        if (content == null) return false;
        const host = this.ref(root, name);
        if (!host) return false;

        if (typeof content === 'string') {
            host.textContent = content;
        } else if (typeof content === 'function' && content.prototype instanceof Component) {
            this.spawn(content as unknown as new () => Component<any>, host);
        } else if (typeof content === 'function') {
            (content as SlotRenderFn)(host, {
                spawn: <T extends Component<any>>(
                    Ctor: new (...args: any[]) => T,
                    h: HTMLElement,
                    ...args: {} extends PropsOf<T> ? [props?: PropsOf<T>] : [props: PropsOf<T>]
                ) => this.spawn(Ctor, h, ...args),
                track: (d: () => void) => this.track(d),
            });
        }
        return true;
    }

    // ─── Directives ──────────────────────────────────────────────

    protected $each<T>(
        host: HTMLElement,
        items: Readable<T[]> | (() => T[]),
        renderer: (item: T, index: number, track: (d: () => void) => void) => HTMLElement,
        key: (item: T, index: number) => string | number = (_item, index) => index
    ): void {
        const read: () => T[] = typeof items === 'function' ? items : () => items.get();
        const nodes = new Map<string | number, HTMLElement>();
        const scopes = new Map<string | number, (() => void)[]>();

        // Clean up all item scopes when component destroys
        this.track(() => {
            for (const fns of scopes.values()) fns.forEach(d => d());
            scopes.clear();
        });

        this.track(effect(() => {
            const list = read();
            const next = new Map<string | number, HTMLElement>();

            for (const [i, item] of list.entries()) {
                const k = key(item, i);
                if (nodes.has(k)) {
                    next.set(k, nodes.get(k)!);
                } else {
                    const itemDisposers: (() => void)[] = [];
                    // Only the list read drives this effect; build each item's DOM
                    // untracked so a signal read inside a renderer (or a component
                    // it spawns) doesn't re-run the whole list on every change.
                    next.set(k, untrack(() => renderer(item, i, d => itemDisposers.push(d))));
                    scopes.set(k, itemDisposers);
                }
            }

            // Remove deleted nodes from DOM and dispose their effects —
            // untracked, so a disposer's signal read can't subscribe the
            // list effect (same teardown-leak hazard as $swap).
            for (const [k, node] of nodes) {
                if (!next.has(k)) {
                    node.remove();
                    untrack(() => scopes.get(k)?.forEach(d => d()));
                    scopes.delete(k);
                }
            }

            // Minimal DOM moves: walk new order, only move out-of-place nodes
            let cursor = host.firstChild;
            for (const node of next.values()) {
                if (node === cursor) {
                    cursor = cursor.nextSibling;
                } else {
                    host.insertBefore(node, cursor);
                }
            }

            nodes.clear();
            for (const [k, v] of next) nodes.set(k, v);
        }));
    }

    protected $condition(
        host: HTMLElement,
        signal: Readable<boolean>,
        onTrue: () => HTMLElement,
        onFalse?: () => HTMLElement
    ): void {
        let current: HTMLElement | null = null;
        this.track(effect(() => {
            if (current) { current.remove(); current = null; }
            // Read the signal tracked (it drives this effect), then build the
            // branch untracked so the branch's own reads don't subscribe here.
            const show = signal.get();
            current = untrack(() => (show ? onTrue() : onFalse?.() ?? null));
            if (current) host.appendChild(current);
        }));
    }

    protected $swap(
        host: HTMLElement,
        signal: Readable<string>,
        map: Record<string, new () => Component<any>>,
        fallback?: new () => Component<any>
    ): void {
        let child: Component<any> | null = null;
        this.track(effect(() => {
            if (child) {
                // Destroy untracked (belt over Component.destroy's own
                // untrack, which an overridden destroy() could bypass): a
                // tracked read during teardown must not subscribe this
                // effect, or the next write re-enters $swap mid-mount and
                // remounts recursively.
                const prev = child;
                child = null;
                untrack(() => prev.destroy());
            }
            host.textContent = '';
            const route = signal.get();
            const Ctor = map[route] ?? matchPrefix(route, map) ?? fallback;
            if (Ctor) {
                // Only the route read above drives this effect. Build + render
                // the child untracked so ITS reads don't subscribe this effect
                // and cause a remount loop on every signal the child touches.
                child = untrack(() => {
                    const c = new Ctor!();
                    c.mount(host);
                    return c;
                });
            }
        }));
        this.track(() => child?.destroy());
    }
}

// ─── App Bootstrap ──────────────────────────────────────────────

interface HotContext {
    data: Record<string, unknown>;
    dispose(cb: () => void): void;
    accept(): void;
}

/**
 * Teardown callbacks to run when the app is disposed — in practice, when Vite
 * replaces the module `startApp` was called from.
 *
 * This exists because Vite keeps exactly ONE dispose callback per module
 * (`disposeMap.set(ownerPath, cb)` in `vite/dist/client/client.mjs`), and
 * `startApp` already claims the app entry's slot for tearing down the component
 * tree. A module that wants disposal of its own — a long-lived service holding
 * a listener, say — therefore cannot reach for `import.meta.hot.dispose()`: it
 * would either overwrite `startApp`'s callback (leaking the whole component
 * tree) or claim its own module's slot, which fires only when THAT module is
 * replaced, which is precisely the case where the stranded instance is created
 * rather than cleaned up.
 *
 * So disposal is registered here and composed by `startApp` instead of
 * competing for a slot that holds one.
 */
const appDisposers = new Set<() => void>();

/**
 * Register `cb` to run when the app is torn down. Returns an unregister
 * function; call it from the owner's own `destroy()` so a disposed instance
 * does not stay reachable through this set.
 *
 * Dev-only in effect: outside HMR nothing disposes an app, so registrations
 * simply accumulate against singletons and are never run. That is why this
 * takes a callback rather than an object with a `destroy()` — there is nothing
 * to keep alive here beyond the closure.
 */
export function onAppDispose(cb: () => void): () => void {
    appDisposers.add(cb);
    return () => appDisposers.delete(cb);
}

/**
 * Drain the registry. Each callback is isolated: one throwing must not strand
 * the ones behind it, because a half-run teardown is the failure mode this is
 * all trying to avoid.
 */
function runAppDisposers(): void {
    for (const cb of Array.from(appDisposers)) {
        appDisposers.delete(cb);
        try {
            cb();
        } catch (err) {
            console.error('[startApp] a dispose callback threw', err);
        }
    }
}

export async function startApp(
    Root: new () => Component<any>,
    root: string | HTMLElement,
    options?: {
        hot?: HotContext | undefined;
        onInit?: (() => void | Promise<void>) | undefined;
        /**
         * Extra teardown to run when the app is disposed, alongside the
         * component tree.
         *
         * Do NOT do this with a second `import.meta.hot.dispose()` in the app
         * entry. Vite stores one dispose callback per module, so a second
         * registration REPLACES the one `startApp` made — trading whatever you
         * were trying to clean up for a leaked component tree. That is a strict
         * loss, and it is why this is a parameter rather than advice.
         */
        onDispose?: (() => void) | undefined;
    }
): Promise<void> {
    const el = typeof root === 'string'
        ? document.querySelector(root) as HTMLElement : root;
    el.textContent = '';

    const router = di.get(Router);
    let app: Component<any> | null = null;
    let inObs = false;
    let ObsShell: (new () => Component<any>) | null = null;
    let initRan = !!options?.hot?.data['hmr'];

    const mount = async (obs: boolean) => {
        if (app) { app.destroy(); app = null; el.textContent = ''; }

        if (obs) {
            if (!ObsShell) {
                const mod = await import('./obs/obs-shell.component');
                ObsShell = mod.ObsShellComponent as unknown as new () => Component<any>;
            }
            app = untrack(() => new ObsShell!());
        } else {
            if (!initRan && options?.onInit) {
                await options.onInit();
                initRan = true;
            }
            app = untrack(() => new Root());
        }

        // mount() is also reachable from the /_obs toggle effect below; build +
        // render the root untracked so it can't subscribe that effect.
        untrack(() => app!.mount(el));
        inObs = obs;
    };

    await mount(stripBase(location.pathname).startsWith('/_obs'));

    effect(() => {
        const wantObs = router.route.get().startsWith('/_obs');
        if (wantObs !== inObs) mount(wantObs);
    });

    if (options?.hot) {
        options.hot.data['hmr'] = true;
        // The app entry's one dispose slot, spent once and composed here.
        //
        // Order is deliberate: the component tree goes first, because it is what
        // holds references INTO the services, and tearing a service down under a
        // live subscriber is the harder failure to reason about. Registered
        // disposers follow, then the caller's own hook last, so an app can rely
        // on everything the framework owns already being closed.
        options.hot.dispose(() => {
            try {
                app?.destroy();
            } catch (err) {
                console.error('[startApp] the root component threw while disposing', err);
            }
            app = null;
            runAppDisposers();
            if (options.onDispose) {
                try {
                    options.onDispose();
                } catch (err) {
                    console.error('[startApp] onDispose threw', err);
                }
            }
        });
        options.hot.accept();
    }
}
